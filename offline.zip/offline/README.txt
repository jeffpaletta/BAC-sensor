The button icons were acting funny when I tried pointing the CSS to the local root of the PNG files, so I uploaded the icons to personal hosting and linked them to their respective web address. For instance:




THIS WORKED FINE:

	url("http://www.jeffpaletta.com/assets/BAC-buttons/liquor-button-white-bold.png”);




THIS WAS BUGGY: 
(i had no idea why, cause this is how you link images…..)

	url(“../img/liquor-button-white-bold.png”);








Because I did this, the page will not load the button icons unless you have an internet connection (so i can find the files on the jeffpaletta.com server).  If this is a problem you can TRY to switch back to the local directory roots by doing the following:

1. unzip the archive named “offline.zip” 
2. open the folder named “offline”
2. copy the file “local.css” 
3. paste the file into the folder named “css”
4. open “index.html”
5. go to line 11
6. change it from:

<link rel="stylesheet" href="css/style.css">

to:

<link rel="stylesheet" href="css/local.css">

4. save